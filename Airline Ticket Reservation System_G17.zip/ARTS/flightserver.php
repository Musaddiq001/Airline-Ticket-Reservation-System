<?php
$cred=array();

$sql="SELECT * FROM `flight` WHERE 1";
	$conn = mysqli_connect("localhost", "root", "","cred");
	$result = mysqli_query($conn, $sql)or die(mysqli_error($conn));
	$c=mysqli_affected_rows($conn);
//print_r($cred);
$flag=0;
$result = $conn->query($sql);
session_start();
if(isset($_SESSION["valid"]) && $_SESSION["valid"]=="yes"){

		$data=array();
		
		
		$conn = mysqli_connect("localhost", "root", "","cred");
		$sql="select * from flight";
		//echo $sql;
		$result = mysqli_query($conn, $sql)or die(mysqli_error($conn));
		while($row = mysqli_fetch_assoc($result)) {
			//echo $row["uname"];echo "<br/>";
			//print_r($row);
			$temp["Flight ID"]=$row["Flight ID"];
			$temp["From"]=$row["Source"];
			$temp["To"]=$row["Destination"];
			$temp["Date"]=$row["Date"];
			$temp["Departure"]=$row["Departure"];
			$temp["Price"]=$row["Price"];
     		$data[]=$temp;
			
		}
	?>
<html lang="en" dir="ltr">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
* {
  box-sizing: border-box;
}

.row::after {
  content: "";
  clear: both;
  display: table;
}

[class*="col-"] {
  float: left;
  padding: 15px;
}

html {
  font-family: "Lucida Sans", sans-serif;
}

.header {
  background-color: #000000;
  color: #ffffff;
  padding: 15px;
}

.menu ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
}

.menu li {
  padding: 8px;
  margin-bottom: 7px;
  background-color: #33b5e5;
  color: #ffffff;
  box-shadow: 0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24);
}

.menu li:hover {
  background-color: #0099cc;
}

.aside {
  background-color: #33b5e5;
  padding: 15px;
  color: #ffffff;
  text-align: center;
  font-size: 14px;
  box-shadow: 0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24);
}

.footer {
  background-color: #0099cc;
  color: #ffffff;
  text-align: center;
  font-size: 12px;
  padding: 15px;
}

/* For mobile phones: */
[class*="col-"] {
  width: 100%;
}

@media only screen and (min-width: 600px) {
  /* For tablets: */
  .col-s-1 {width: 8.33%;}
  .col-s-2 {width: 16.66%;}
  .col-s-3 {width: 25%;}
  .col-s-4 {width: 33.33%;}
  .col-s-5 {width: 41.66%;}
  .col-s-6 {width: 50%;}
  .col-s-7 {width: 58.33%;}
  .col-s-8 {width: 66.66%;}
  .col-s-9 {width: 75%;}
  .col-s-10 {width: 83.33%;}
  .col-s-11 {width: 91.66%;}
  .col-s-12 {width: 100%;}
}
@media only screen and (min-width: 768px) {
  /* For desktop: */
  .col-1 {width: 8.33%;}
  .col-2 {width: 16.66%;}
  .col-3 {width: 25%;}
  .col-4 {width: 33.33%;}
  .col-5 {width: 41.66%;}
  .col-6 {width: 50%;}
  .col-7 {width: 58.33%;}
  .col-8 {width: 66.66%;}
  .col-9 {width: 75%;}
  .col-10 {width: 83.33%;}
  .col-11 {width: 91.66%;}
  .col-12 {width: 100%;}
}
</style>

</head>
<body>
<form id="fm" form action="flight.php" method="post">

<div class="header">
<body>
    <span style="font-size: 20px">Welcome, <?php echo "<a href='userprofile.php'>" . $_SESSION["uname"] . "</a>" ; ?></span>

    <br><br>
</div>


<div class="row">
  <div class="col-3 col-s-3 menu">
    <table class="Flight" width="100%">
        <tr class="Flight_row">
          <th colspan="4">Flight</th>
        </tr>
        <tr class="Flight_row">
          <th colspan="4"> <hr> </th>
        </tr>
        <tr class="Flight_row">
          <th>Flight ID</th>
          <th>From</th>
          <th>To</th>
		  <th>Date</th>
		  <th>Departure</th>
		  <th>Price</th>

        </tr>
        <tr class="Flight_row">
          <th><hr></th>
          <th><hr></th>
          <th><hr></th>
		  <th><hr></th>
		  <th><hr></th>
		  <th><hr></th>
		  
          </tr>
        <?php
          foreach($data as $v){?>
              <tr class="Flight_row">
              <td align="center"><span class="F_ID" style="color:white" ><a href="flight.php?Flight ID=><?php echo $v["Flight ID"];?>"><?php echo $v["Flight ID"];?></a</span></td>
              <td align="center"><span class="F_From"><?php echo $v["From"];?></span></td>
              <td align="center"><span class="F_To"><?php echo $v["To"];?></span></td>
			  <td align="center"><span class="F_Date"><?php echo $v["Date"];?></span></td>
			  <td align="center"><span class="F_Departure"><?php echo $v["Departure"];?></span></td>
			  <td align="center"><span class="F_Price"><?php echo $v["Price"];?></span></td>
              </tr>
        <?php
            }
          }
        ?>
      </table>

      <hr>

	
  </div>

  <div class="col-6 col-s-9">
  

    <h1>Welcome to Airline Ticket Reservation System</h1>
	<p><img src="virgin.jpg" alt="Plane" width="620" height="350"></p>
  </div>
  <div class="col-3 col-s-12">
  <div class="aside">
    <p><a href="userprofile.php" style="color:white">Back</a><br/></p>
	
    </div>
  </div>
  
</div>
<div class="footer">
  
</div>

</body>
</html>