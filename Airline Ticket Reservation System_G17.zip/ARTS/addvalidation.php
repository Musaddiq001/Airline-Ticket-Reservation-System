<?php
//$file=fopen('cred.txt','a') or die("fle open error");
$c=0;

if(strlen($_REQUEST["from"])==0 || strlen($_REQUEST["to"])==0){
	echo "All fields are mandatory!";
}

else{
	//$sql="insert into user values('".$_REQUEST["uname"]."','".md5($_REQUEST["pass"])."','".$_REQUEST["email"]."')";
	//echo $sql;
	$sql="INSERT INTO `flight`(`Source`, `Destination`, `Departure`, `Date`, `Price`) values('".$_REQUEST["from"]."','".$_REQUEST["to"]."','".$_REQUEST["departure"]."','".$_REQUEST["date"]."','".$_REQUEST["price"]."')";
	$conn = mysqli_connect("localhost", "root", "","cred");
	$result = mysqli_query($conn, $sql)or die(mysqli_error($conn));
	$c=mysqli_affected_rows($conn);
	/*$c=$c+fwrite($file,"\r\n");
	$c=$c+fwrite($file,$_REQUEST["uname"]);
	$c=$c+fwrite($file,"-");
	$c=$c+fwrite($file,md5($_REQUEST["pass"]));
	$c=$c+fwrite($file,"-");
	$c=$c+fwrite($file,$_REQUEST["email"]);*/
}
echo "<br/>";
echo " Added";
header ("Location:flightserver1.php");
?>
