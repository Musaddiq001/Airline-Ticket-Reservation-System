<?php
//$file=fopen('cred.txt','a') or die("fle open error");
$c=0;

if(strlen($_REQUEST["f"])==0 || strlen($_REQUEST["u"])==0){
	echo "All fields are mandatory!";
}
else{
	//$sql="insert into user values('".$_REQUEST["uname"]."','".md5($_REQUEST["pass"])."','".$_REQUEST["email"]."')";
	//echo $sql;
	$sql="insert into reserved values('".$_REQUEST["f"]."','".$_REQUEST["u"]."')";
	$conn = mysqli_connect("localhost", "root", "","cred");
	$result = mysqli_query($conn, $sql)or die(mysqli_error($conn));
	$c=mysqli_affected_rows($conn);
	/*$c=$c+fwrite($file,"\r\n");
	$c=$c+fwrite($file,$_REQUEST["uname"]);
	$c=$c+fwrite($file,"-");
	$c=$c+fwrite($file,md5($_REQUEST["pass"]));
	$c=$c+fwrite($file,"-");
	$c=$c+fwrite($file,$_REQUEST["email"]);*/
}
echo "<br/>";
echo " Purchased";

?>
</br> <a href="userprofile.php" style="color:white">Back</a><br/></p>
