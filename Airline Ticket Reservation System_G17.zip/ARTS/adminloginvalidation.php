<?php
		$data=array();		
		$conn = mysqli_connect("localhost", "root", "","cred");
		$sql="select * from user where uname='".$_REQUEST["uname"]."'";
		//echo $sql;
		$result = mysqli_query($conn, $sql)or die(mysqli_error($conn));
		while($row = mysqli_fetch_assoc($result)) {
			//echo $row["uname"];echo "<br/>";
			//print_r($row);
			$temp["uname"]=$row["uname"];
			$temp["pass"]=$row["password"];
			$temp["email"]=$row["email"];
			$data[]=$temp;
		}


//print_r($cred);
$flag=0;
session_start();
foreach($data as $k=>$v){
	if($_REQUEST["uname"]==$data[$k]["uname"] && md5($_REQUEST["pass"])==$data[$k]["pass"]){
		echo "Login success";
		$_SESSION["valid"]="yes";
		$_SESSION["uname"]=$_REQUEST["uname"];
		$flag=1;
		break;
	}
}
if($flag==0){
	echo "<p style='color:red'>Wrong credentials</p>";
}
if($flag==1){
	header("Location:adminprofile.php");
    echo "<p succesfull</p?";
}

?>